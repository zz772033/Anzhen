import Vue from 'vue';
import Vuex from 'vuex';
import { cloneObject } from '../aeUtils';

Vue.use(Vuex);

function genEntity(options) {
    if (!options) return null;
    options = cloneObject(options);
    if (options.billboard) options.billboard = fixBillboardOptions(options.billboard);
    if (options.box) options.box = fixBoxOptions(options.box);
    if (options.label) options.label = fixLabelOptions(options.label);
    if (options.model) options.model = fixModelOptions(options.model);
    if (options.point) options.point = fixPointOptions(options.point);
    if (options.polygon) options.polygon = fixPolygonOptions(options.polygon);
    if (options.polyline) options.polyline = fixPolylineOptions(options.polyline);
    if (options.position) options.position = fixPosition(options.position);
    if (options.orientation) options.orientation = fixOrientation(options.position, options.orientation);
    if (options.properties && typeof options.properties === 'object' && !(options.properties instanceof Cesium.PropertyBag)) options.properties = new Cesium.PropertyBag(options.properties);
    let feature = new Cesium.Entity(options);
    // if (feature) {
    //     feature.name = name;
    //     feature.type = 'feature';
    //     feature.show = visible;
    // }
    return feature;
}

function fixPosition(position) {
    if (!position) return null;
    if (position instanceof Cesium.Cartesian3) return position;
    if (position.latitude && position.longitude) {
        if (-Math.PI <= position.longitude && position.longitude <= Math.PI && -Math.PI / 2 <= position.latitude && position.latitude <= Math.PI / 2) {
            position = Cesium.Cartesian3.fromRadians(position.longitude, position.latitude, position.height);
        } else {
            position = Cesium.Cartesian3.fromDegrees(position.longitude, position.latitude, position.height);
        }
    } else {
        position = new Cesium.Cartesian3(position.x, position.y, position.z);
    }
    return position;
}

function fixPointOptions(options) {
    if (options.color) options.color = fixColor(options.color);
    // pixelSize: number
    // if (options.outlineColor) options.outlineColor = fixColor(options.outlineColor);
    // outlineWidth: number
    // show: boolean
    // if (options.scaleByDistance) options.scaleByDistance = fixScaleByDistance(options.scaleByDistance);
    // if (options.translucencyByDistance) options.translucencyByDistance = fixTranslucencyByDistance(options.translucencyByDistance);
    // if (options.heightReference) options.heightReference = fixHeightReference(options.heightReference);
    // if (options.distanceDisplayCondition) options.distanceDisplayCondition = fixDistanceDisplayCondition(options.distanceDisplayCondition);
    // disableDepthTestDistance: number
    // var fixPointOptions = fixPointOptions(options);

    return options;
}

function fixColor(option) {
    return typeof option === 'string' ? Cesium.Color.fromCssColorString(option) : null;
}


// function fixBillboardOptions(options) {
//     return options;
// }

// function fixBoxOptions(options) {
//     return options;
// }

// function fixLabelOptions(options) {
//     return options;
// }

// function fixModelOptions(options) {
//     return options;
// }

// function fixPolygonOptions(options) {
//     return options;
// }

// function fixPolylineOptions(options) {
//     return options;
// }

// function fixPosition(options) {
//     return options;
// }

// function fixOrientation(options) {
//     return options;
// }
export default { genEntity, };