import Vue from 'vue';
import axios from 'axios';
import VueAxios from 'vue-axios';

Vue.use(VueAxios, axios);

import aeEntityManager from './entityManager/aeEntityManager';

export default {
    data() {
        return {
            picker: null
        };
    },
    mounted() {
        this.createEntity({
            id: '001point',
            position: { longitude: 120.128920, latitude: 30.268324 },
            point: {
                color: '#ff0000',
                outlineColor: '#0000ff',
                outlineWidth: 10,
                show: true,
                scaleByDistance: {
                    near: 0,
                    nearValue: 0,
                    far: 1,
                    farValue: 150000,
                },
                // translucencyByDistance,
                // heightReference:
            }
        });
    },
    methods: {
        createEntity(options) {
            let entity = aeEntityManager.genEntity(options);
            this.viewer.entities.add(entity);
            viewer.zoomTo(entities);
        },

        toDegrees(radians) {
            return Cesium.Math.toDegrees(radians);
        },
        toRadians(degrees) {
            return Cesium.Math.toRadians(degrees);
        },
        XYZ2LLH(pos) {
            if (!pos || !pos.x || !pos.y || !pos.z) return null;
            if (this.viewer && this.viewer.scene && this.viewer.scene.globe && this.viewer.scene.globe.ellipsoid) {
                let cartographic = this.viewer.scene.globe.ellipsoid.cartesianToCartographic(new Cesium.Cartesian3(pos.x, pos.y, pos.z));
                return {
                    longitude: Cesium.Math.toDegrees(cartographic.longitude),
                    latitude: Cesium.Math.toDegrees(cartographic.latitude),
                    height: cartographic.height
                };
            }
            return null;
        },
        LLH2XYZ(pos) {
            if (!pos || !pos.longitude || !pos.latitude || !pos.height) return null;
            if (this.viewer && this.viewer.scene && this.viewer.scene.globe && this.viewer.scene.globe.ellipsoid) {
                let position = {};
                if (-Math.PI <= pos.longitude && pos.longitude <= Math.PI && -Math.PI / 2 <= pos.latitude && pos.latitude <= Math.PI / 2) {
                    position = Cesium.Cartesian3.fromRadians(pos.longitude, pos.latitude, pos.height, this.viewer.scene.globe.ellipsoid);
                } else {
                    position = Cesium.Cartesian3.fromDegrees(pos.longitude, pos.latitude, pos.height, this.viewer.scene.globe.ellipsoid);
                }
                return {
                    x: position.x,
                    y: position.y,
                    z: position.z
                };
            }
            return null;
        },
        addImageryLayer(name, visible, provider, options, index) {
            return ImageryManager.addImagery(this.viewer, ImageryManager.genImagery(name, visible, provider, options), index);
        },
        delImageryLayer(name) {
            return ImageryManager.delImagery(this.viewer, name, false);
        },
        delImageryLayers(name) {
            return ImageryManager.delImagery(this.viewer, name, true);
        },
        getImageryLayerByName(name) {
            return ImageryManager.getImagery(this.viewer, name);
        },
        getImageryLayersByName(name) {
            return ImageryManager.getImageries(this.viewer, name);
        },
        getImageryLayers() {
            return ImageryManager.getImageries(this.viewer);
        },
        setImageryLayerVisible(imageryLayer, visible) {
            if (!imageryLayer || !(imageryLayer instanceof Cesium.ImageryLayer)) return false;
            imageryLayer.show = visible;
            return true;
        },
        setImageryLayerAlpha(imageryLayer, alpha) {
            if (!imageryLayer || !(imageryLayer instanceof Cesium.ImageryLayer)) return false;
            imageryLayer.alpha = alpha;
            return true;
        },

        // genGrids(range, dimensions) {
        //     if (!this.viewer) return null;
        //     return DataSourceManager.addDataSource(this.viewer, DataSourceManager.genGrids(range, dimensions));
        // },
        async loadDataSource(name, visible, provider, data, options) {
            if (!this.viewer) return null;
            let ret = null;
            await DataSourceManager.loadDataSource(name, visible, provider, data, options).then(ds => {
                ret = DataSourceManager.addDataSource(this.viewer, ds);
            });
            return ret;
        },
        delDataSource(name) {
            return DataSourceManager.delDataSource(this.viewer, name, false);
        },
        delDataSources(name) {
            return DataSourceManager.delDataSource(this.viewer, name, true);
        },
        getDataSourceByName(name) {
            return DataSourceManager.getDataSource(this.viewer, name);
        },
        getDataSourcesByName(name) {
            return DataSourceManager.getDataSources(this.viewer, name);
        },
        getDataSources() {
            return DataSourceManager.getDataSources(this.viewer);
        },
        setDataSourceVisible(datasource, visible) {
            if (!datasource) return false;
            datasource.show = visible;
            return true;
        },

        /*
            addFeature(name, visible, options, parent) {
                let feature = FeatureManager.genFeature(name, visible, options);
                if (feature && parent && parent instanceof Cesium.Entity) {
                    feature.parent = parent;
                    feature.type = '';
                }
                return FeatureManager.addFeature(this.viewer, feature);
            },
            */
        addFeature(name, visible, options) {
            if (Array.isArray(options)) return FeatureManager.addFeatures(this.viewer, FeatureManager.genFeatures(name, visible, options));
            return FeatureManager.addFeature(this.viewer, FeatureManager.genFeature(name, visible, options));
        },
        delFeature(name) {
            return FeatureManager.delFeature(this.viewer, name, false);
        },
        delFeatures(name) {
            return FeatureManager.delFeature(this.viewer, name, true);
        },
        getFeatureByName(name) {
            return FeatureManager.getFeature(this.viewer, name);
        },
        getFeaturesByName(name) {
            return FeatureManager.getFeatures(this.viewer, name);
        },
        getFeatures() {
            return FeatureManager.getFeatures(this.viewer);
        },
        setFeatureVisible(feature, visible) {
            if (!feature) return false;
            feature.show = visible;
            return true;
        },

        async loadModel(name, visible, position, rotation, options, distanceDisplayCondition) {
            if (!this.viewer) return null;
            let ret = null;
            await ModelManager.loadModelAsync(name, visible, position, rotation, options, distanceDisplayCondition).then(model => {
                ret = ModelManager.addModel(this.viewer, model);
            });
            return ret;
        },
        addModel(name, visible, position, rotation, options, distanceDisplayCondition) {
            return ModelManager.addModel(this.viewer, ModelManager.loadModel(name, visible, position, rotation, options, distanceDisplayCondition));
        },
        delModel(name) {
            return ModelManager.delModel(this.viewer, name, false);
        },
        delModels(name) {
            return ModelManager.delModel(this.viewer, name, true);
        },
        getModelByName(name) {
            return ModelManager.getModel(this.viewer, name);
        },
        getModelsByName(name) {
            return ModelManager.getModels(this.viewer, name);
        },
        getModels() {
            return ModelManager.getModels(this.viewer, null);
        },
        setModelVisible(model, visible) {
            if (!model) return false;
            model.show = visible;
            return true;
        },
        setNodesVisible(model, visibles) {
            if (!model || typeof visibles !== 'object') return false;
            let conditions = [];
            for (let id in visibles) {
                if (id === 'default') continue;
                conditions.push(['${id}===' + id, visibles[id] ? 'true' : 'false']);
            }
            let left = true;
            if (visibles.hasOwnProperty('default')) left = visibles['default'] ? 'true' : 'false';
            conditions.push(['true', left]);

            let style = {};
            if (model.style && model.style.style) style = model.style.style;
            style.show = { conditions };
            model.style = new Cesium.Cesium3DTileStyle(style);
            return true;
        },
        setNodesColor(model, colors) {
            if (!model || typeof colors !== 'object') return false;
            let conditions = [];
            for (let id in colors) {
                if (id === 'default') continue;
                conditions.push(['${id}===' + id, colors[id]]);
            }
            conditions.push(['true', colors.hasOwnProperty('default') ? colors['default'] : 'rgba(255,255,255,1.0)']);

            let style = {};
            if (model.style && model.style.style) style = model.style.style;
            style.color = { conditions };
            model.style = new Cesium.Cesium3DTileStyle(style);
            return true;
        },

        setClock(start, stop, current, multiplier = 1.0, loop = true) {
            if (!this.viewer || !this.viewer.clock) return false;
            if (!(start instanceof Date) || !(stop instanceof Date)) return false;
            this.viewer.clock.startTime = Cesium.JulianDate.fromDate(start);
            this.viewer.clock.stopTime = Cesium.JulianDate.fromDate(stop);
            this.viewer.clock.currentTime = current && current instanceof Date ? Cesium.JulianDate.fromDate(current) : this.viewer.clock.startTime.clone();
            this.viewer.clock.clockRange = loop ? Cesium.ClockRange.LOOP_STOP : Cesium.ClockRange.CLAMPED;
            this.viewer.clock.multiplier = multiplier;
            return true;
        },
        addPathAnimation(name, visible, date, paths, options) {
            return PathAnimationManager.addPathAnimation(this.viewer, PathAnimationManager.genPathAnimation(name, visible, date, paths, options));
        },
        delPathAnimation(name) {
            return PathAnimationManager.delPathAnimation(this.viewer, name, false);
        },
        delPathAnimations(name) {
            return PathAnimationManager.delPathAnimation(this.viewer, name, true);
        },
        getPathAnimationByName(name) {
            return PathAnimationManager.getPathAnimation(this.viewer, name);
        },
        getPathAnimationsByName(name) {
            return PathAnimationManager.getPathAnimations(this.viewer, name);
        },
        getPathAnimations() {
            return PathAnimationManager.getPathAnimations(this.viewer);
        },
        setPathAnimationVisible(pa, visible) {
            if (!pa) return false;
            pa.show = visible;
            return true;
        },

        getCamera() {
            if (!this.viewer || !this.viewer.camera) return {};

            let llh = {};
            try {
                let cartesian = this.viewer.camera.pickEllipsoid(new Cesium.Cartesian2(this.viewer.canvas.clientWidth / 2, this.viewer.canvas.clientHeight / 2));
                let cartographic = this.viewer.scene.globe.ellipsoid.cartesianToCartographic(cartesian);
                llh.longitude = Cesium.Math.toDegrees(cartographic.longitude);
                llh.latitude = Cesium.Math.toDegrees(cartographic.latitude);
                llh.height = cartographic.height;
            } catch (err) {
                llh = null;
            }

            return {
                location: llh,
                position: {
                    x: this.viewer.camera.position.x,
                    y: this.viewer.camera.position.y,
                    z: this.viewer.camera.position.z
                },
                orientation: {
                    heading: Cesium.Math.toDegrees(this.viewer.camera.heading),
                    pitch: Cesium.Math.toDegrees(this.viewer.camera.pitch),
                    roll: Cesium.Math.toDegrees(this.viewer.camera.roll)
                }
            };
        },
        unlockCamera() {
            if (!this.viewer || !this.viewer.camera) return false;
            this.viewer.camera.lookAtTransform(Cesium.Matrix4.IDENTITY);
        },
        lockCamera() {
            if (!this.viewer || !this.viewer.camera) return false;

            let llh = {};
            try {
                let cartesian = this.viewer.camera.pickEllipsoid(new Cesium.Cartesian2(this.viewer.canvas.clientWidth / 2, this.viewer.canvas.clientHeight / 2));
                let cartographic = this.viewer.scene.globe.ellipsoid.cartesianToCartographic(cartesian);
                llh.longitude = Cesium.Math.toDegrees(cartographic.longitude);
                llh.latitude = Cesium.Math.toDegrees(cartographic.latitude);
                llh.height = cartographic.height;
            } catch (err) {
                return false;
            }

            let p1 = Cesium.Cartesian3.fromDegrees(llh.longitude, llh.latitude, llh.height);
            let p2 = this.viewer.camera.positionWC;
            this.viewer.camera.lookAt(p1, new Cesium.HeadingPitchRange(this.viewer.camera.heading, this.viewer.camera.pitch, Cesium.Cartesian3.distance(p1, p2)));
            return true;
        },

        flyTo(object, heading, pitch, range, duration) {
            if (!this.viewer || !object) return false;
            if (!pitch) pitch = -45;
            if (pitch > -0.001) pitch = -0.001;
            if (pitch < -90) pitch = -90;
            // this.viewer.camera.lookAtTransform(Cesium.Matrix4.IDENTITY);
            return this.viewer.flyTo(object, {
                offset: new Cesium.HeadingPitchRange(Cesium.Math.toRadians(heading || 0), Cesium.Math.toRadians(pitch), range || 100),
                duration
            });
        },
        flyToLocation(longitude, latitude, height, heading, pitch, range, duration) {
            if (!this.viewer || !this.viewer.camera) return false;
            if (!pitch) pitch = -45;
            if (pitch > -0.001) pitch = -0.001;
            if (pitch < -90) pitch = -90;
            let camera1 = new Cesium.Camera(this.viewer.scene);
            camera1.lookAt(Cesium.Cartesian3.fromDegrees(longitude, latitude, height), new Cesium.HeadingPitchRange(Cesium.Math.toRadians(heading || 0), Cesium.Math.toRadians(pitch), range || 100));
            // this.viewer.camera.lookAtTransform(Cesium.Matrix4.IDENTITY);
            return this.viewer.camera.flyTo({
                destination: camera1.positionWC,
                orientation: {
                    heading: Cesium.Math.toRadians(heading || 0),
                    pitch: Cesium.Math.toRadians(pitch),
                    roll: 0.0
                },
                duration
            });
        },
        flyToPosition(x, y, z, heading, pitch, roll, duration) {
            if (!this.viewer || !this.viewer.camera) return false;
            if (!pitch) pitch = -45;
            if (pitch > -0.001) pitch = -0.001;
            if (pitch < -90) pitch = -90;
            // this.viewer.camera.lookAtTransform(Cesium.Matrix4.IDENTITY);
            this.viewer.camera.flyTo({
                destination: new Cesium.Cartesian3(x, y, z),
                orientation: {
                    heading: Cesium.Math.toRadians(heading || 0),
                    pitch: Cesium.Math.toRadians(pitch),
                    roll: 0.0
                },
                duration
            });
            return true;
        },
        lookAtLocation(longitude, latitude, height, heading, pitch, range) {
            if (!this.viewer || !this.viewer.camera) return false;
            if (!pitch) pitch = -45;
            if (pitch > -0.001) pitch = -0.001;
            if (pitch < -90) pitch = -90;
            return this.viewer.camera.lookAt(Cesium.Cartesian3.fromDegrees(longitude, latitude, height), new Cesium.HeadingPitchRange(Cesium.Math.toRadians(heading || 0), Cesium.Math.toRadians(pitch), range || 100));
        },
        lookAtPosition(x, y, z, heading, pitch, range) {
            if (!this.viewer || !this.viewer.camera) return false;
            if (!pitch) pitch = -45;
            if (pitch > -0.001) pitch = -0.001;
            if (pitch < -90) pitch = -90;
            return this.viewer.camera.lookAt(new Cesium.Cartesian3(x, y, z), new Cesium.HeadingPitchRange(Cesium.Math.toRadians(heading || 0), Cesium.Math.toRadians(pitch), range || 100));
        },
        trackEntity(entity) {
            if (!this.viewer) return false;
            this.viewer.trackdEntity = entity;
            return true;
        },

        setGlobeVisible(visible) {
            if (!this.viewer || !this.viewer.scene) return false;
            if (this.viewer.scene.globe) this.viewer.scene.globe.show = visible;
            if (this.viewer.scene.skyAtmosphere) this.viewer.scene.skyAtmosphere.show = visible;
            if (this.viewer.scene.sun) this.viewer.scene.sun.show = visible;
            if (this.viewer.scene.moon) this.viewer.scene.moon.show = visible;
            return true;
        },
        setSkyBox({ positiveX, negativeX, positiveY, negativeY, positiveZ, negativeZ }) {
            if (!this.viewer || !this.viewer.scene) return false;
            let sb = new Cesium.SkyBox({ sources: { positiveX, negativeX, positiveY, negativeY, positiveZ, negativeZ } });
            if (!sb) return false;
            this.viewer.scene.skyBox = sb;
            return true;
        },
        bindAction(action, func) {
            if (typeof func !== 'function') return false;
            if (typeof action !== 'string') return false;
            switch (action.toUpperCase()) {
                case 'LEFT_CLICK':
                    action = Cesium.ScreenSpaceEventType.LEFT_CLICK;
                    break;
                case 'LEFT_DOUBLE_CLICK':
                    action = Cesium.ScreenSpaceEventType.LEFT_DOUBLE_CLICK;
                    break;
                case 'LEFT_DOWN':
                    action = Cesium.ScreenSpaceEventType.LEFT_DOWN;
                    break;
                case 'LEFT_UP':
                    action = Cesium.ScreenSpaceEventType.LEFT_UP;
                    break;
                case 'MOUSE_MOVE':
                    action = Cesium.ScreenSpaceEventType.MOUSE_MOVE;
                    break;
                case 'MIDDLE_CLICK':
                    action = Cesium.ScreenSpaceEventType.MIDDLE_CLICK;
                    break;
                case 'MIDDLE_DOWN':
                    action = Cesium.ScreenSpaceEventType.MIDDLE_DOWN;
                    break;
                case 'MIDDLE_UP':
                    action = Cesium.ScreenSpaceEventType.MIDDLE_UP;
                    break;
                case 'RIGHT_CLICK':
                    action = Cesium.ScreenSpaceEventType.RIGHT_CLICK;
                    break;
                case 'RIGHT_DOWN':
                    action = Cesium.ScreenSpaceEventType.RIGHT_DOWN;
                    break;
                case 'RIGHT_UP':
                    action = Cesium.ScreenSpaceEventType.RIGHT_UP;
                    break;
                default:
                    return false;
            }
            if (!this.picker) return false;

            this.picker.setInputAction(mouse => {
                let viewer = this.viewer;
                if (!viewer) return;
                let scene = viewer.scene;
                if (!scene) return;

                let xy = action === Cesium.ScreenSpaceEventType.MOUSE_MOVE ? mouse.endPosition : mouse.position;
                let cartesian = null;
                let position = null;
                let picked = scene.pick(xy);
                if (picked) {
                    cartesian = scene.pickPosition(xy);
                } else if (viewer.camera) {
                    cartesian = viewer.camera.pickEllipsoid(xy);
                }
                if (cartesian && scene.globe && scene.globe.ellipsoid) {
                    let cartographic = scene.globe.ellipsoid.cartesianToCartographic(cartesian);
                    if (cartographic) position = { longitude: Cesium.Math.toDegrees(cartographic.longitude), latitude: Cesium.Math.toDegrees(cartographic.latitude), height: cartographic.height };
                }
                func(picked, position);
            }, action);
            return true;
        },

        addHighlightHandler(color) {
            if (!this.viewer || !this.viewer.scene || !this.viewer.scene.postProcessStages) return null;
            let handler = this.viewer.scene.postProcessStages.add(
                new Cesium.PostProcessStage({
                    fragmentShader: `
uniform sampler2D colorTexture;
varying vec2 v_textureCoordinates;
uniform vec4 highlight;
void main() {
    vec4 color = texture2D(colorTexture, v_textureCoordinates);
    if (czm_selected())
        gl_FragColor = vec4(highlight.a * highlight.rgb + (1.0 - highlight.a) * color.rgb, 1.0 - highlight.a);
    else
        gl_FragColor = color;
}`,
                    uniforms: {
                        highlight: Cesium.Color.fromCssColorString(color)
                    }
                })
            );
            if (handler) {
                handler.selected = [];
                Object.defineProperty(handler, 'target', {
                    get() {
                        return this.selected;
                    },
                    set(target) {
                        handler.selected = !target ? [] : Array.isArray(target) ? target : [target];
                    }
                });
                Object.defineProperty(handler, 'color', {
                    get() {
                        return this.uniforms.highlight.toCssColorString();
                    },
                    set(color) {
                        this.uniforms.highlight = Cesium.Color.fromCssColorString(color);
                    }
                });
            }
            return handler;
        },
        delHighlightHandler(handler) {
            if (!this.viewer || !this.viewer.scene || !this.viewer.scene.postProcessStages) return false;
            if (!handler || !(handler instanceof Cesium.PostProcessStage)) return false;
            handler.selected = [];
            handler.destroy();
            // return this.viewer.scene.postProcessStages.remove(handler);
            return true;
        },

        ajax(method, url, params) {
            return Vue.axios({
                url,
                method,
                baseURL: this.configs.baseURL,
                headers: { Authorization: 'JWT ' + this.$cookies.get('token') },
                params,
                responseType: 'json'
            });
        }
    }
};